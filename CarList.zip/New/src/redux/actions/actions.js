export const addCarDetails = (carDetails) => {
     return {
          type: "ADD_CAR_DETAILS",
          payload: carDetails,
     };
};
export const clearCarDetails = () => {
     return {
          type: "CLEAR_CAR_DETAILS",
     };
};
