import React, { useContext, useState } from "react";
import { connect } from "react-redux";
import { addCarDetails } from "./redux/actions/actions";
import { AppContext } from './AppContext';

const Details = (props) => {
     const selectedCar = useContext(AppContext);

     const [formData, setFormData] = useState({
          model: selectedCar?.sharedData,
          color: "",
          yearOfManufacture: "",
          insuranceValidUpto: "",
          kms: "",
          location: "",
          noOfOwners: "",
          transmission: "",
          externalFitments: "",
     });
     

     const [formSubmitted, setFormSubmitted] = useState(false);

     const handleInputChange = (field, value) => {
          setFormData({
               ...formData,
               [field]: value,
          });
     };

     const handleFormSubmit = () => {
          const jsonData = {
               ...formData,
          };

          console.log(jsonData);
          props.addCarDetails(jsonData);

          setFormSubmitted(true);
     };
     return (
          <div className="car-details-form">
               <h2>Enter the Car Details:</h2>

               {formSubmitted ? (
                    <div>
                         <h3>JSON Values:</h3>
                         <pre>{JSON.stringify(formData, null, 2)}</pre>
                    </div>
               ) : (
                    <div>
                         <div className="form-row">
                              <label className="input-container">
                                   Model:
                                   <input
                                        type="text"
                                        value={
                                             formData.model !== ""
                                                  ? formData.model
                                                  : selectedCar
                                                         .charAt(0)
                                                         .toUpperCase() +
                                                    selectedCar.slice(1)
                                        }
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "model",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Color:
                                   <input
                                        type="text"
                                        value={formData.color}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "color",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   Year of Manufacture:
                                   <input
                                        type="number"
                                        value={formData.yearOfManufacture}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "yearOfManufacture",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Insurance Valid Upto:
                                   <input
                                        type="number"
                                        value={formData.insuranceValidUpto}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "insuranceValidUpto",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   Kms:
                                   <input
                                        type="number"
                                        value={formData.kms}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "kms",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Location:
                                   <input
                                        type="text"
                                        value={formData.location}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "location",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   No of Owners:
                                   <input
                                        type="number"
                                        value={formData.noOfOwners}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "noOfOwners",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Transmission:
                                   <input
                                        type="text"
                                        value={formData.transmission}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "transmission",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                         </div>
                         <div className="form-row">
                              <label className="input-container">
                                   External Fitments:
                                   <input
                                        type="text"
                                        value={formData.externalFitments}
                                        onChange={(e) =>
                                             handleInputChange(
                                                  "externalFitments",
                                                  e.target.value
                                             )
                                        }
                                   />
                              </label>
                              <label className="input-container">
                                   Browse:
                                   <input type="file" />
                              </label>
                         </div>
                         <div className="form-row">
                              <button type="button" onClick={handleFormSubmit}>
                                   Submit
                              </button>
                         </div>
                    </div>
               )}
          </div>
     );
};
const mapStateToProps = (state) => {
     return {
          carDetails: state.carDetails,
     };
};

const mapDispatchToProps = {
     addCarDetails,
};

export default connect(mapStateToProps, mapDispatchToProps)(Details);
